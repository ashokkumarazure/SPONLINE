/* tslint:disable */
require('./AzureFunctionWebPartWebPart.module.css');
const styles = {
  azureFunctionWebPart: 'azureFunctionWebPart_ae1e66b4',
  container: 'container_ae1e66b4',
  row: 'row_ae1e66b4',
  column: 'column_ae1e66b4',
  'ms-Grid': 'ms-Grid_ae1e66b4',
  title: 'title_ae1e66b4',
  subTitle: 'subTitle_ae1e66b4',
  description: 'description_ae1e66b4',
  button: 'button_ae1e66b4',
  label: 'label_ae1e66b4',
};

export default styles;
/* tslint:enable */