declare interface IAzureFunctionWebPartWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'AzureFunctionWebPartWebPartStrings' {
  const strings: IAzureFunctionWebPartWebPartStrings;
  export = strings;
}
