import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';
import { escape } from '@microsoft/sp-lodash-subset';
import { HttpClient, SPHttpClient, HttpClientConfiguration, HttpClientResponse, ODataVersion, IHttpClientConfiguration, IHttpClientOptions, ISPHttpClientOptions } from '@microsoft/sp-http';
import styles from './AzureFunctionWebPartWebPart.module.scss';
import * as strings from 'AzureFunctionWebPartWebPartStrings';
import { IData } from './IData';

export interface IAzureFunctionWebPartWebPartProps {
  description: string;
}

export default class AzureFunctionWebPartWebPart extends BaseClientSideWebPart<IAzureFunctionWebPartWebPartProps> {

  protected functionUrl: string = "https://spfxcaller.azurewebsites.net/api/HttpTrigger1";

  protected callAzureFunction(): void {
      const requestHeaders: Headers = new Headers();
      requestHeaders.append("Content-type", "text/plain");
      requestHeaders.append("Cache-Control", "no-cache");

      var siteUrl: string = this.context.pageContext.web.absoluteUrl;
      var userName: string = (<HTMLInputElement>document.getElementById("txtUserName")).value;

      console.log(`SiteUrl: '${siteUrl}', UserName: '${userName}'`);

      const postOptions: IHttpClientOptions = {
        headers: requestHeaders,
        body: `{ name: '${userName}' }`
      };

      let responseText: string = "";
      let resultMsg: HTMLElement = document.getElementById("responseContainer");

      this.context.httpClient.post(this.functionUrl, HttpClient.configurations.v1, postOptions).then((response: HttpClientResponse) => {
         response.json().then((responseJSON: IData) => {
            //responseText = JSON.stringify(responseJSON);
            if (response.ok) {
                resultMsg.style.color = "white";
            } else {
                resultMsg.style.color = "red";
            }

            resultMsg.innerText = responseJSON.name;
          })
          .catch ((response: any) => {
            let errMsg: string = `WARNING - error when calling URL ${this.functionUrl}. Error = ${response.message}`;
            resultMsg.style.color = "red";
            console.log(errMsg);
            resultMsg.innerText = errMsg;
          });
      });
  }

  public render(): void {
    this.domElement.innerHTML = `
      <div class="${ styles.azureFunctionWebPart }">
        <div class="${ styles.container }">
          <div class="${ styles.row }">
            <div class="${ styles.column }">
              <span class="${ styles.title }">Call Azure Function</span>
              <p class="${ styles.subTitle }">Customize SharePoint experiences using Web Parts.</p>

              <div class="${styles.row}">
                <span class="ms-font-l ms-fontColor-white ${styles.label}">User name:</span>
                <input type="text" id="txtUserName"></input>
              </div>

              <button id="btnCallAzureFunction" class="${styles.button}">Say Hello!</button>
              <div id="responseContainer" class="${styles.label}"></div>

            </div>
          </div>
        </div>
      </div>`;

      document.getElementById("btnCallAzureFunction").onclick = this.callAzureFunction.bind(this);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
