/* tslint:disable */
require('./ConsumeMsGraph.module.css');
const styles = {
  consumeMsGraph: 'consumeMsGraph_5deb0e38',
  form: 'form_5deb0e38',
  container: 'container_5deb0e38',
  row: 'row_5deb0e38',
  column: 'column_5deb0e38',
  'ms-Grid': 'ms-Grid_5deb0e38',
  title: 'title_5deb0e38',
  subTitle: 'subTitle_5deb0e38',
  description: 'description_5deb0e38',
  button: 'button_5deb0e38',
  label: 'label_5deb0e38',
};

export default styles;
/* tslint:enable */