export interface IUserItem {
    displayName: string;
    mail: string;
    userPrincipalName: string;
}