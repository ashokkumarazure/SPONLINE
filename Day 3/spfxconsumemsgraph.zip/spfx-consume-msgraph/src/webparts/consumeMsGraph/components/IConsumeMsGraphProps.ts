import { WebPartContext } from '@microsoft/sp-webpart-base';

export interface IConsumeMsGraphProps {
  description: string;
  context: WebPartContext;
}
