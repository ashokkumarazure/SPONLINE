declare interface IConsumeMsGraphWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ConsumeMsGraphWebPartStrings' {
  const strings: IConsumeMsGraphWebPartStrings;
  export = strings;
}
