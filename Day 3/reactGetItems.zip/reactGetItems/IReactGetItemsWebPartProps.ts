export interface IReactGetItemsWebPartProps {
  description: string;
}
