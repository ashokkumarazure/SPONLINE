declare interface IReactGetItemsStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'reactGetItemsStrings' {
  const strings: IReactGetItemsStrings;
  export = strings;
}
