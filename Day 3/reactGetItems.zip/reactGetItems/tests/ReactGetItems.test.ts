/// <reference types="mocha" />

import { assert } from 'chai';

describe('ReactGetItemsWebPart', () => {
  it('should do something', () => {
    assert.ok(true);
  });
});
