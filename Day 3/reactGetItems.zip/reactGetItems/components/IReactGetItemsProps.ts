export interface IReactGetItemsProps {
  description: string;
   siteurl: string; 
}
