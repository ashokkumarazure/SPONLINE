/* tslint:disable */
require('./ReactGetItems.module.css');
const styles = {
  tableStyle: 'tableStyle_4afaae8b',
  panelStyle: 'panelStyle_4afaae8b',
  divStyle: 'divStyle_4afaae8b',
  headerCaptionStyle: 'headerCaptionStyle_4afaae8b',
  headerStyle: 'headerStyle_4afaae8b',
  tableCaptionStyle: 'tableCaptionStyle_4afaae8b',
  rowCaptionStyle: 'rowCaptionStyle_4afaae8b',
  rowStyle: 'rowStyle_4afaae8b',
  CellStyle: 'CellStyle_4afaae8b',
};

export default styles;
/* tslint:enable */